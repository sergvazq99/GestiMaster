CREATE TABLE Facultades (
    nombre VARCHAR(100) PRIMARY KEY
);